CREATE TABLE transacciones
(descripcion varchar(50), fecha varchar(10), monto DECIMAL, cuenta INT);